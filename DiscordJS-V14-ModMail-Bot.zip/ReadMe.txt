/*
* DiscordJS-V14-ModMail-Bot
* Yet Another Discord ModMail Bot made with discord.js v14, built on Repl.it and coded by TRXCORE TEAM https://discord.gg/trxcore.
* Developer: TRXCORE TEAM https://discord.gg/trxcore
* Support server: dsc.gg/codingdevelopment
* Please DO NOT remove these lines, these are the credits to the developer.
* Sharing this project without giving credits to TrxCore Team ends in a Copyright warning. (©)
*/
